import { expenseServices } from '@/api/service'
import AppButton from '@/components/AppButton'
import ExpenseFormDrawer from '@/components/forms/expenseForm'
import Header from '@/components/home/Header'
import KpiContainer from '@/components/home/KpiContainer'
import { BUDGETOPTIONS, CATEGORYOPTIONS } from '@/constants/data'
import { ExpenseType } from '@/types'
import React from 'react'
import { StyleSheet } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import useKpi from '../../../modules/home/hooks/useKpi'


const HomeScreen = () => {
  const {kpiList} = useKpi()

  const [AddExpenseVisible, setAddExpenseVisible] = React.useState(false);
  const handleSubmitExp = async(formData:ExpenseType)=>{
   const response = await expenseServices.create(formData)
  }
  const handleKpiPress = (kpi: any) => {
  }
  const handleFilterChange = (date: Date) => {
    console.log(date)
  }
  return (
    <SafeAreaView style={styles.container} > 
      <Header onChange={handleFilterChange}/>
        <KpiContainer kpiList={kpiList} onKpiPress={handleKpiPress} />
        <AppButton title="Add Expense" onPress={()=>setAddExpenseVisible(true)}/>
         <ExpenseFormDrawer visible={AddExpenseVisible} onClose={()=>{setAddExpenseVisible(false)}} budgets={BUDGETOPTIONS} categories={CATEGORYOPTIONS} onSubmit={handleSubmitExp} />
  
    </SafeAreaView>
  )
}

export default HomeScreen

const styles = StyleSheet.create({
    container:{
       flex: 1,
    }
})