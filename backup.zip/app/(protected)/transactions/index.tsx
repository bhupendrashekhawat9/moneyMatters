import { expenseServices } from '@/api/service';
import AppButton from '@/components/AppButton';
import RecentTrnxContainer from '@/components/transactions/RecentTrnxContainer';
import TransactionFilter from '@/components/transactions/transactionFilter';
import useExpenseStore from '@/store/useExpenseStore';
import { ExpenseType } from '@/types';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';


const TransactionsScreen = () => {
  const {expenses,setExpenses}:{expenses:ExpenseType[]} = useExpenseStore()
  const [filteredTrnx, setFilteredTrnx] = useState(() => expenses);
  const onTransactionPress = (transaction: any) => {
    router.push(`/transactions/details`, {
      params: { transactionId: transaction.id },
    } as any);
  };
  const onFilterChange = (newFilter: any) => {
    setFilteredTrnx(newFilter);
  };
  const refresh = () => {
    expenseServices.getAll().then((response) => {
        if(response.status == "SUCCESS"){
            setExpenses(response.data)
        }
    })
  }
  useEffect(() => {
      expenseServices.getAll().then((response) => {
       
          if(response.status == "SUCCESS"){
              setExpenses(response.data)
          }
      })
  }, [])
  useEffect(() => {
    setFilteredTrnx(expenses)
  }, [expenses])


  return (
    <View style={styles.container}>
      <AppButton title="Refresh" onPress={refresh} />
      <TransactionFilter transactions={expenses} onFilterChange={onFilterChange} />
      <RecentTrnxContainer onTransactionPress={onTransactionPress} transactions={filteredTrnx} />
    </View>
  )
}

export default TransactionsScreen

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center', 
        alignItems: 'center',
        padding:10
    },
})