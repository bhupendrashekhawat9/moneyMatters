import { homeServices } from '@/api/service'
import React from 'react'
import { StyleSheet } from 'react-native'

const useKpi = () => {
    const [kpiList, setKpiList] = React.useState([])
    const [loading, setLoading] = React.useState(false)
    const [error, setError] = React.useState(null)

    const getKpiList = async() => {
        setLoading(true)
        try {
            const response = await homeServices.getSecondaryKpi()
            if(response.status == "SUCCESS"){
                setKpiList(response.data)
            }else{
                setError(response.message)
            }
        } catch (error) {
            setError(error)
        }finally{
            setLoading(false)
        }
    }

    const getPrimaryKpi = async() => {
        setLoading(true)
        try {
            const response = await homeServices.getPrimaryKpi({userId:"1"})
            if(response.status == "SUCCESS"){
              setKpiList(response.data)
            }else{
                setError(response.message)
            }
        } catch (error) {
            setLoading(false)
            setError(error)
        }finally{
            setLoading(false)
        }
    }

    React.useEffect(() => {
        // getKpiList()
        getPrimaryKpi()
    }, [])

    return {
        kpiList,
        loading,
        error
    }
}

export default useKpi

const styles = StyleSheet.create({})